## create notification message that appears when raindrop reaches bottom
class Notification():
    x = 0.0
    y = 0.0
    def __init__(self,ypos):
        global x, y
        self.x = 0
        self.y = ypos
        
    def setLocation(self, xpos):
        global x, y
        self.x = xpos
        
    def display(this):
        global x, y
        noStroke()
        fill(0)
        textSize(16)
        textAlign(CENTER)
        text("You miss me!", this.x, this.y)
    
    