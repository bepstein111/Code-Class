class Drop():

    r = 20  # radus of drop
    x = None
    y = None

    def __init__(self):
        global x, y, speed, c
        self.x = random(width)
        self.y = 0
        self.speed = random(1, 4)

    def move(self):
        global y, speed
        self.y = self.y + self.speed

    def display(self):
        global x, y, d, img
        noStroke()
        img = loadImage("balloon.png")
        image(img,self.x,self.y,20,30)

    def reachedBottom(self):
        if (self.y > height + self.r):
            return True
        else:
            return False
        
    def intersect(self, other):
        distance = dist(self.x, self.y, other.x, other.y)
        if (distance < self.r + other.r):
            return True
        else:
            return False