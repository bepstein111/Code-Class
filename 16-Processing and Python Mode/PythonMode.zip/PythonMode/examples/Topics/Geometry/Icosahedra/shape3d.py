class Shape3D(object):

    def __init__(self, x=0, y=0, z=0):
        self.locationX = x
        self.locationY = y
        self.locationZ = z
